import { useParams } from "react-router-dom"

import "../Routes/RoutesCSS/PropertyDetails.css"
import properties from "../dummyData"
import ImageGallery from "../Components/Property/ImageGallery"
import ShareLikePrint from "../Components/Property/ShareLikePrint"
import CustomerCard from "../Components/Customer/CustomerCard"

const PropertyDetails = () => {
    const { id } = useParams<{ id: string }>()

    const property = properties.filter((property) => property.id === id)[0]

    return (
        <div className="property-details-container">
            <div className="property-details">
                <div className="property-image-gallery">
                    <ImageGallery property={property} />
                </div>
                <div className="share-like-prints">
                    <ShareLikePrint />
                    <CustomerCard />
                </div>

            </div>
            <div className="property-info-container">
                <div className="property-info-header">
                    <h1>{property.city}</h1>
                    <span>- {property.transactionType} {property.propertyType}</span>
                </div>
                <div className="property-info-base">
                    <div>
                        <div>Location</div>
                        <p>{property.district}</p>
                    </div>
                    <div>
                        <div>Floor area</div>
                    </div>
                    <div>
                        <div>Asking Price</div>
                    </div>
                    <div>
                        <div>Listing Id</div>
                    </div>
                </div>
            </div>

        </div>)
}

export default PropertyDetails